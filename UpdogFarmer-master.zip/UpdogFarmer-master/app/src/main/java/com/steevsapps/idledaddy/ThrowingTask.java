package com.steevsapps.idledaddy;

public interface ThrowingTask {
    void run() throws Exception;
}
