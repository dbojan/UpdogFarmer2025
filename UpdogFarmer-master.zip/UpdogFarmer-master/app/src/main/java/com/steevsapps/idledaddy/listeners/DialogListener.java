package com.steevsapps.idledaddy.listeners;

public interface DialogListener {
    void onYesPicked(String text);
}
