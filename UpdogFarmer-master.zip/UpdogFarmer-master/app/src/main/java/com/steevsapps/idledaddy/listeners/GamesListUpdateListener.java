package com.steevsapps.idledaddy.listeners;

public interface GamesListUpdateListener {
    void onGamesListUpdated();
}
