## Idle Daddy

Steam Trading Card farmer for Android

<a href='https://play.google.com/store/apps/details?id=com.steevsapps.idledaddy'><img alt='Get it on Google Play' src='https://play.google.com/intl/en_us/badges/images/generic/en_badge_web_generic.png' height='80px'/></a>
